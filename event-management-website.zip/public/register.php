<?php
session_start();
require_once __DIR__ . '/../config/db.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) {
        $error = 'Enter a valid name/email and a password of at least 6 characters.';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (name,email,password) VALUES (?,?,?)");
        $stmt->bind_param("sss", $name, $email, $hash);
        if ($stmt->execute()) {
            header('Location: login.php?registered=1');
            exit;
        }
        $error = $stmt->errno === 1062 ? 'Email already registered.' : 'Registration failed.';
    }
}
?>
<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Register</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body><?php include __DIR__.'/partials/nav.php'; ?><main class="container"><form class="form" method="post"><h2>Create Account</h2><?php if($error): ?><div class="alert"><?=htmlspecialchars($error)?></div><?php endif; ?><label>Name</label><input name="name" required><label>Email</label><input type="email" name="email" required><label>Password</label><input type="password" name="password" minlength="6" required><button class="btn" type="submit">Register</button></form></main></body></html>
