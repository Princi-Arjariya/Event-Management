<?php
session_start();
require_once __DIR__ . '/../config/db.php';

$result = $conn->query("SELECT e.*, COUNT(r.id) AS registered FROM events e LEFT JOIN registrations r ON e.id=r.event_id GROUP BY e.id ORDER BY e.event_date ASC");
?>
<!doctype html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>EventHub</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
<?php include __DIR__ . '/partials/nav.php'; ?>
<main class="container">
<section class="hero">
<h1>Plan. Discover. Experience.</h1>
<p>Manage events, discover upcoming experiences and register in a few clicks.</p>
<a class="btn" href="#events">Explore Events</a>
</section>

<h2 id="events">Upcoming Events</h2>
<div class="grid">
<?php while($event=$result->fetch_assoc()): ?>
<div class="card">
<h3><?= htmlspecialchars($event['title']) ?></h3>
<p class="muted"><?= date('d M Y, h:i A', strtotime($event['event_date'])) ?></p>
<p><?= htmlspecialchars($event['venue']) ?></p>
<p><?= htmlspecialchars(substr($event['description'],0,120)) ?>...</p>
<p><strong><?= (int)$event['registered'] ?>/<?= (int)$event['capacity'] ?></strong> registered</p>
<a class="btn" href="event.php?id=<?= (int)$event['id'] ?>">View Event</a>
</div>
<?php endwhile; ?>
</div>
</main>
<script src="assets/js/app.js"></script>
</body>
</html>
