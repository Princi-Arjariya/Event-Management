<?php
session_start();
require_once __DIR__ . '/../config/db.php';
if(!isset($_SESSION['user_id'])){header('Location: login.php');exit;}
$user_id=(int)$_SESSION['user_id'];
$stmt=$conn->prepare("SELECT e.title,e.event_date,e.venue,r.registered_at FROM registrations r JOIN events e ON r.event_id=e.id WHERE r.user_id=? ORDER BY e.event_date");
$stmt->bind_param("i",$user_id);$stmt->execute();$events=$stmt->get_result();
?>
<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body><?php include __DIR__.'/partials/nav.php'; ?><main class="container"><h1>Welcome, <?=htmlspecialchars($_SESSION['name'])?></h1><?php if(isset($_GET['registered'])):?><div class="alert success">Event registration successful.</div><?php endif;?><h2>My Events</h2><div class="grid"><?php while($e=$events->fetch_assoc()): ?><div class="card"><h3><?=htmlspecialchars($e['title'])?></h3><p><?=date('d M Y, h:i A',strtotime($e['event_date']))?></p><p><?=htmlspecialchars($e['venue'])?></p></div><?php endwhile; ?></div></main></body></html>
