<?php
session_start();
require_once __DIR__ . '/../config/db.php';
if(!isset($_SESSION['user_id'])){header('Location: login.php');exit;}
$event_id=(int)($_POST['event_id'] ?? 0);
$user_id=(int)$_SESSION['user_id'];

$stmt=$conn->prepare("SELECT capacity,(SELECT COUNT(*) FROM registrations WHERE event_id=e.id) AS registered FROM events e WHERE e.id=?");
$stmt->bind_param("i",$event_id);$stmt->execute();$event=$stmt->get_result()->fetch_assoc();
if(!$event){die('Event not found.');}
if((int)$event['registered'] >= (int)$event['capacity']){die('Event is full.');}

$stmt=$conn->prepare("INSERT INTO registrations(user_id,event_id) VALUES(?,?)");
$stmt->bind_param("ii",$user_id,$event_id);
if(!$stmt->execute() && $stmt->errno !== 1062){die('Could not register.');}
header('Location: dashboard.php?registered=1');exit;
