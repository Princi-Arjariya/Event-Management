<?php
session_start();
require_once __DIR__ . '/../config/db.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $stmt = $conn->prepare("SELECT id,name,password,role FROM users WHERE email=? LIMIT 1");
    $stmt->bind_param("s",$email); $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    if ($user && password_verify($password,$user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user_id']=(int)$user['id']; $_SESSION['name']=$user['name']; $_SESSION['role']=$user['role'];
        header('Location: dashboard.php'); exit;
    }
    $error='Invalid email or password.';
}
?>
<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body><?php include __DIR__.'/partials/nav.php'; ?><main class="container"><form class="form" method="post"><h2>Login</h2><?php if(isset($_GET['registered'])): ?><div class="alert success">Registration successful. Please login.</div><?php endif; ?><?php if($error): ?><div class="alert"><?=htmlspecialchars($error)?></div><?php endif; ?><label>Email</label><input type="email" name="email" required><label>Password</label><input type="password" name="password" required><button class="btn">Login</button></form></main></body></html>
