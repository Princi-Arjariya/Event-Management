<?php
session_start();
require_once __DIR__ . '/../config/db.php';
if(!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin'){http_response_code(403);die('Access denied');}
$message='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $title=trim($_POST['title']??'');$description=trim($_POST['description']??'');$date=$_POST['event_date']??'';$venue=trim($_POST['venue']??'');$capacity=(int)($_POST['capacity']??0);
    if($title && $description && $date && $venue && $capacity>0){
        $stmt=$conn->prepare("INSERT INTO events(title,description,event_date,venue,capacity) VALUES(?,?,?,?,?)");
        $stmt->bind_param("ssssi",$title,$description,$date,$venue,$capacity);$stmt->execute();$message='Event created.';
    }
}
if(isset($_GET['delete'])){$id=(int)$_GET['delete'];$stmt=$conn->prepare("DELETE FROM events WHERE id=?");$stmt->bind_param("i",$id);$stmt->execute();header('Location: admin.php');exit;}
$events=$conn->query("SELECT e.*,COUNT(r.id) registered FROM events e LEFT JOIN registrations r ON e.id=r.event_id GROUP BY e.id ORDER BY e.event_date");
?>
<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body><?php include __DIR__.'/partials/nav.php'; ?><main class="container"><h1>Admin Panel</h1><?php if($message):?><div class="alert success"><?=htmlspecialchars($message)?></div><?php endif;?><form class="form" method="post"><h2>Create Event</h2><input name="title" placeholder="Event title" required><textarea name="description" placeholder="Description" required></textarea><input type="datetime-local" name="event_date" required><input name="venue" placeholder="Venue" required><input type="number" name="capacity" min="1" placeholder="Capacity" required><button class="btn">Create Event</button></form><h2>Manage Events</h2><div class="grid"><?php while($e=$events->fetch_assoc()):?><div class="card"><h3><?=htmlspecialchars($e['title'])?></h3><p><?=date('d M Y, h:i A',strtotime($e['event_date']))?></p><p><?=htmlspecialchars($e['venue'])?></p><p><?=(int)$e['registered']?> registrations</p><a class="btn danger" data-confirm="Delete this event?" href="admin.php?delete=<?=(int)$e['id']?>">Delete</a></div><?php endwhile;?></div></main><script src="assets/js/app.js"></script></body></html>
