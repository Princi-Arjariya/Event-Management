<nav class="navbar">
<a class="brand" href="index.php">EventHub</a>
<div class="navlinks">
<a href="index.php">Home</a>
<?php if(isset($_SESSION['user_id'])): ?>
<a href="dashboard.php">Dashboard</a>
<?php if(($_SESSION['role'] ?? '') === 'admin'): ?><a href="admin.php">Admin</a><?php endif; ?>
<a href="logout.php">Logout</a>
<?php else: ?>
<a href="login.php">Login</a><a class="btn" href="register.php">Register</a>
<?php endif; ?>
</div>
</nav>
