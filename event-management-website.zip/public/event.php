<?php
session_start();
require_once __DIR__ . '/../config/db.php';
$id=(int)($_GET['id'] ?? 0);
$stmt=$conn->prepare("SELECT e.*, COUNT(r.id) AS registered FROM events e LEFT JOIN registrations r ON e.id=r.event_id WHERE e.id=? GROUP BY e.id");
$stmt->bind_param("i",$id); $stmt->execute();
$event=$stmt->get_result()->fetch_assoc();
if(!$event){http_response_code(404);die('Event not found');}
?>
<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=htmlspecialchars($event['title'])?></title><link rel="stylesheet" href="assets/css/style.css"></head>
<body><?php include __DIR__.'/partials/nav.php'; ?><main class="container"><div class="card"><h1><?=htmlspecialchars($event['title'])?></h1><p class="muted"><?=date('d M Y, h:i A',strtotime($event['event_date']))?></p><p><strong>Venue:</strong> <?=htmlspecialchars($event['venue'])?></p><p><?=nl2br(htmlspecialchars($event['description']))?></p><p><strong>Seats:</strong> <?=max(0,(int)$event['capacity']-(int)$event['registered'])?> remaining</p>
<?php if(isset($_SESSION['user_id'])): ?>
<?php if((int)$event['registered'] >= (int)$event['capacity']): ?><p class="alert">This event is full.</p><?php else: ?><form method="post" action="register_event.php"><input type="hidden" name="event_id" value="<?=$id?>"><button class="btn">Register for Event</button></form><?php endif; ?>
<?php else: ?><a class="btn" href="login.php">Login to Register</a><?php endif; ?>
</div></main></body></html>
