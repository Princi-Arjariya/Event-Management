CREATE DATABASE IF NOT EXISTS event_management;
USE event_management;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user','admin') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    event_date DATETIME NOT NULL,
    venue VARCHAR(200) NOT NULL,
    capacity INT NOT NULL DEFAULT 100,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    event_id INT NOT NULL,
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_registration (user_id, event_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);

INSERT IGNORE INTO users (id, name, email, password, role)
VALUES (
    1,
    'Admin',
    'admin@example.com',
    '$2y$10$0yL0vL7w9n7u6u5V8l4Z8eW9M6n7X8Y0GQ0cM2d1R8QqR2r6w2m8u',
    'admin'
);

INSERT INTO events (title, description, event_date, venue, capacity)
SELECT 'Tech Innovation Summit',
       'A student-focused event covering AI, software development and emerging technology.',
       '2026-10-15 10:00:00',
       'Main Auditorium',
       200
WHERE NOT EXISTS (SELECT 1 FROM events WHERE title = 'Tech Innovation Summit');

INSERT INTO events (title, description, event_date, venue, capacity)
SELECT 'Startup & Entrepreneurship Meetup',
       'Meet founders, learn about product building and explore startup ideas.',
       '2026-10-25 14:00:00',
       'Innovation Hall',
       120
WHERE NOT EXISTS (SELECT 1 FROM events WHERE title = 'Startup & Entrepreneurship Meetup');
