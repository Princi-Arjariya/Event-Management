<?php
declare(strict_types=1);

$host = getenv('DB_HOST') ?: 'db';
$db   = getenv('DB_NAME') ?: 'event_management';
$user = getenv('DB_USER') ?: 'event_user';
$pass = getenv('DB_PASS') ?: 'event_pass';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Database connection failed: " . htmlspecialchars($conn->connect_error));
}

$conn->set_charset("utf8mb4");
?>
