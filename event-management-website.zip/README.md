# Event Management Website

A beginner-friendly full-stack Event Management website built with PHP, MySQL, HTML, CSS and JavaScript.

## Features
- User registration and login
- Password hashing
- Session-based authentication
- Browse events
- Event details
- Event registration
- User dashboard with registered events
- Admin dashboard
- Admin can create/delete events
- MySQL database
- Docker Compose setup for GitHub Codespaces

## Run in GitHub Codespaces

1. Open this repository in GitHub Codespaces.
2. In the terminal run:

```bash
docker compose up -d --build
```

3. Open the forwarded port **8080**.
4. Website: `http://localhost:8080`
5. phpMyAdmin: `http://localhost:8081`

Database credentials:
- Database: `event_management`
- User: `event_user`
- Password: `event_pass`
- Root password: `root_pass`

The database schema and seed data are loaded automatically.

## Demo admin account

Email: `admin@example.com`
Password: `Admin@123`

Change this password before using the project publicly.

## Project structure

```text
event-management-website/
├── .devcontainer/
│   └── devcontainer.json
├── config/
│   └── db.php
├── database/
│   └── schema.sql
├── public/
│   ├── assets/
│   │   ├── css/style.css
│   │   └── js/app.js
│   ├── admin.php
│   ├── dashboard.php
│   ├── event.php
│   ├── index.php
│   ├── login.php
│   ├── logout.php
│   ├── register.php
│   └── register_event.php
├── docker/
│   └── apache-vhost.conf
├── Dockerfile
├── docker-compose.yml
└── README.md
```
